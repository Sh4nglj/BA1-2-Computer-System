
int conditional(int, int, int);
int test_conditional(int, int, int);
int isNonNegative(int);
int test_isNonNegative(int);
int isGreater(int, int);
int test_isGreater(int, int);
int absVal(int);
int test_absVal(int);
int isPower2(int);
int test_isPower2(int);
unsigned float_neg(unsigned);
unsigned test_float_neg(unsigned);
unsigned float_i2f(int);
unsigned test_float_i2f(int);
